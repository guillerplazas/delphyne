# ACE investigation — short checkpoint assessment

**All launched batches have finished, and new experiments are on hold for the API-key change.** We have 1,019 finished solver attempts: 655 of the 1,520 main benchmark cells, all 80 rule-repair attempts, 80 source runs and 204 pilot runs. One rule-repair attempt ended with a context-window error; its cost and failed outcome are retained. The other 1,025 planned attempts remain queued.

**The most promising version is still the short Sol-medium playbook, with Luna solving.** On the completed twelve-problem pilot it solved 11 instead of 9 problems and cost $0.11395 instead of $0.26758: **57.4% less**. The nine problems outside its learning examples show the same direction. This is a selected pilot; its full trainX/validationX benchmark has not started.

The first complete forty-problem validation replicate gives a different result for the long books:

| Pipeline | Solved / 40 | Cost |
|---|---:|---:|
| Ordinary assisted agent | 28 | $0.8513 |
| Historical X5 ACE | 29 | $1.1222 |
| New full Sol ACE | 25 | $1.0948 |
| Ordinary plain agent | 25 | $0.9076 |
| Full Sol ACE, plain | 26 | $1.1558 |
| Full Sol ACE with teacher evidence, plain | 25 | $1.0123 |

**Why the long books are struggling:** their lessons do not consistently shorten expensive failed searches enough to repay the extra input. In the full Sol book, failures consume 84.3% of inference spending. One failed theorem explains 82.6% of its excess cost. Stronger authors also produce incorrect tactic advice: executable probes caught rules that passed reflection, curation and auditing. Those errors are now documented and three repairs were measured; they have not yet demonstrated a cost win.

**There is already a useful budgeting result.** Replaying the ordinary agent with a $0.05 rather than $0.10 stopping allowance saves **14.9% on the complete validation replicate with the same 28/40 solves**, and **10.7% on the complete train replicate with the same 32/40**. These are saved-trajectory controller results, not new model samples or an ACE-specific benefit. ACE still needs comparison against an equally budgeted baseline.

For preparation, six completed author-only calls demonstrate **18.8% lower total cost** by avoiding unused cache writes. That is separate from the solver-cost target. The settled investigation bill is **$282.33**: $22.57 solving, $257.59 learning/author selection and $2.17 cache diagnostics.

When you continue, the first priority is the already registered full benchmark of the short book. Its compact preparation recipe is a stronger current direction than another larger author sweep; executable checks should support any later lesson changes. TrainX benchmarking is appropriate: frozen reuse of familiar problems and online prediction-before-learning are reported separately, following the ACE paper's distinction. ValidationX remains development data; testX stays closed.

The [long report](long_report.md) explains the diagnoses, paper methodology, costs, uncertainty and improvement directions. The [evidence index](artifact_index.md) links raw-data-derived tables and checks. All 1,019 attempts are accounted for; 1,018 replay normally, the terminal rejection reproduces offline, and 652 distinct proofs compile independently. No API request remains in flight.

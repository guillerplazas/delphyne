# Evidence and reproduction index — user-requested checkpoint

The [short report](short_report.md) explains the current findings; the
[long report](long_report.md) gives the methods, numerical evidence, diagnosis,
and improvement directions. Both are checkpoint reports: queued experiments
remain on hold at the user's request. Neither claims the registered study is
complete. The [package README](../../experiments/ace_independent_audit/README.md)
contains the same commands for Codex and Claude Code.

## Completed fresh evidence

| Artifact | Contents |
|---|---|
| [Checkpoint results](checkpoint_results.json) | Completed and pending denominators, every settled API fee, complete-replicate comparisons, online operating costs |
| [Completed cells](checkpoint_cells.json) | Every completed solver cell, including partial replicates; hashes, billed usage and trace summaries |
| [Cost mechanisms](checkpoint_mechanisms.json) | Failed-trajectory spending, token/cache categories, and every paired theorem's contribution |
| [Replicate table](checkpoint_tables.md) | Readable forty-problem results; no unfinished replicate is presented as a full panel |
| [Replicate CSV](checkpoint_replicates.csv) | Cost, coverage, request counts, failed-attempt fees, paired theorem and family uncertainty |
| [Budget replay results](checkpoint_budget_results.json) | Completed deterministic lower-budget replays; no new model calls |
| [Budget CSV](checkpoint_budget_replicates.csv) | Complete-replicate results at each stopping allowance |
| [Receipt certification](checkpoint_receipt_certification.json) | Every raw provider receipt repriced, including cache writes, context premiums, tier and endpoint |
| [Online chronology](checkpoint_chronology.json) | Completed predict-before-update events; an additional scored step can be awaiting learning |
| [Learning scope](checkpoint_learning_scope.json) | All learning evidence uses trainX; six author-cache diagnostics preserve source content |
| [Settled receipt CSV](checkpoint_settled_receipts.csv) | One row per provider call at the settled checkpoint |
| [Preparation economics](preparation_economics.json) | Five completed frozen-book recipes, source fees, author fees and teacher work |
| [Learning cost breakdown](learning_cost_breakdown.json) | Input/output tokens, unused cache writes and long-context author costs |
| [Cache diagnostic](learning_cache_diagnostic.json) | Six completed author-only calls; measured preparation savings, no benchmark treatment |
| [Rule provenance](book_signal.json) | Every retained rule's originating source and observed source outcome |
| [Figures](figures/README.md) | Standalone PNG, SVG and PDF figures from the audited numbers |

The 1,520-cell main finalizer, two-replicate arm comparisons, O1 frozen-book
follow-up and final full-study certification remain pending. The checkpoint
uses separate filenames and does not replace their denominator requirements.

## Historical reconstruction and controlled diagnostics

The [audit inventory](audit_inventory.json) selects only permitted individual
raw cells. The [census completion record](audit_completion.json),
[descriptive catalogue](all_variants.csv), [solver panels](historical_solver_panels.csv),
[learning roles](historical_learning_roles.csv) and
[matched comparisons](historical_matched_comparisons.csv) separate complete
panels, partial pilots and author jobs.

[Continuation reconciliation](historical_continuations.json) identifies
explicit replayed prefixes. The [reconciled panels](historical_reconciled_panels.csv)
remove duplicate recorded calls. [Original-loop comparisons](historical_original_comparisons.json)
remain separate from later grounded-agent contracts.

[Historical proof certification](historical_proof_certification.json) compiles
all 3,485 distinct returned scripts, covering 4,953 reported-solved cells.
The [monolithic parser check](monolithic_parser_certification.json) evaluates
all 196 saved replies without new calls. [Ten tactic probes](rule_probe_certification.json)
and [six rule-repair probes](rule_repair_certification.json) test specific
claims in executable Rocq, with incorrect draft imports preserved and excluded.

The large `raw_cells.jsonl` and `exception_cells.jsonl` remain locally available.
They were reconstructed from permitted raw cells rather than inherited reports.
Their per-cell result/cache hashes preserve the evidence chain.

## Protocols and retained raw evidence

The [campaign directory](../../experiments/campaigns/ace_independent_audit)
contains write-once protocols, exact job lists, sealed source hashes and actual
books. `HOLD_NEW_BATCHES.json` records the latest user instruction.
`runs/` and `responses/` contain paid execution caches and raw provider replies;
`role_inputs/`, `learning_events/`, `online_scores/` and `online_events/` record
learning provenance. `verification/` and `kernel/` retain exact replays and
independent compiler evidence. `incidents/` preserves diagnosed mistakes.

The [checkpoint manifest](checkpoint_artifact_manifest.json) hashes the compact
review bundle. The [raw evidence inventory](checkpoint_raw_artifact_hashes.jsonl)
hashes retained local data and the settled ledger snapshot. Large caches and
provider-response files remain local; the manifest explicitly distinguishes
them from staged deliverables. No API credential is copied into this bundle.

Source collection, learning and probes use trainX; frozen serving uses trainX
and validationX. ValidationX remains reused development data. No closed
benchmark partition or protected challenge artifact is included or read.

# Figure provenance

Every figure is supplied as PNG, SVG and standalone PDF. Historical tariffs
are normalized to September 19; fresh figures use audited provider receipts.

- `historical_cost_components`: full original-agentic validationX panels,
  eighty attempts each; input/output billing and coverage.
- `author_pilot`: the eight fuller-evidence author recipes and shared no-book
  control, twelve trainX problems each; exploratory candidate selection.
- `checkpoint_complete_replicates`: one complete forty-problem validationX
  replicate and one complete online trainX order. Learning fees are excluded
  from the plotted solver costs and reported in the long report.

Reproduce the checkpoint figure with
`python -m experiments.ace_independent_audit.checkpoint_tables`.
Do not invoke `figures final` until the registered full study is complete.
The plot code reads only audited artifacts from this investigation.

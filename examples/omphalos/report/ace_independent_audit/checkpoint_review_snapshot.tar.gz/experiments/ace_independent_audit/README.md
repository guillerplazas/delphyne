# Independent ACE investigation

This package reconstructs permitted historical measurements, runs the
registered Luna solver study, and certifies its costs and returned proofs.
It uses only `trainX` and `validationX`. It never imports the eager mixed
partition loader. Both Claude Code and Codex use the same Python commands;
there is no harness-specific runtime dependency.

Run commands from `examples/omphalos` in the project's Python 3.12 environment.
Rocq, the configured opam switch, and the ordinary Omphalos runtime are needed
for new proof attempts or independent proof compilation. New paid calls also
require `OPENAI_API_KEY` in the launching process. The experiment launcher
reserves machine-wide Rocq slots, applies the registered worker memory limit,
and owns each output directory's lock. Long jobs can run in an ordinary tmux
session with that environment inherited.

## Study and evidence boundaries

The study fixes Luna medium, Responses, 32 requests, a $0.10 stopping allowance,
32,768 output tokens, the original two core tools, definitions, informal
sketches, and fixed tool-use demonstrations. Assisted and plain checking have
their own matched non-ACE controls. Stronger models operate only in playbook
preparation. A stopping allowance admits a crossing request and is not a hard
billing ceiling.

The registered main study has 1,520 solver cells: 1,280 frozen-book cells and
240 online ACE cells. Online courses reuse 160 of the frozen matrix's trainX
controls. Separately registered R1 and O1 follow-ups add 80 and 160 cells.
Source collection (80) and author selection (204) make 2,044 solver cells
overall. Three lower-budget replays per frozen cell produce 4,560 conditional
controller scenarios without new model calls. They do not increase the number
of independent samples.

Campaign inputs, protocols, receipts, raw responses, and execution caches live
under `experiments/campaigns/ace_independent_audit`. Compact findings and
certifications live under `report/ace_independent_audit`. Write-once JSON
artifacts are compared for exact equality when resuming. Existing paid books,
source files, and caches must not be edited to obtain a different result.
`completed.json` is written after a worker returns; a periodic `result.yaml`
alone is not evidence that the attempt is finished.

The ledger's $10,000 administrative capacity implements the user's unlimited
API authorization; it is not a spend target. Calls have recorded liability,
raw responses are persisted before parsing, and unknown billing pauses the
campaign. Never resolve an unknown bill by silently assigning it zero cost.

## Inspect and resume registered work

**Current status: user-requested hold on new experiments, September 19.**
The `HOLD_NEW_BATCHES.json` marker allows already launched batches to finish
and prevents subsequent solver, author, and teacher batches from dispatching.
The commands below describe the registered workflow; do not remove this
marker or resume work without the user's continuation. An API-key change
must apply to the future launching process; this package never records the
key in an artifact.

The following command only prints progress and updates `STATUS.txt`. It does
not stop experiments or make API calls:

```bash
python -m experiments.ace_independent_audit.status
```

Initial campaign preparation and source collection:

```bash
python -m experiments.ace_independent_audit prepare
python -m experiments.ace_independent_audit run-batch source run --max_workers=16 --wait
python -m experiments.ace_independent_audit prepare-evidence
```

The preparation workflows are explicitly versioned. The original author
ladder and its fuller-evidence follow-up are recorded in `workflow.py` and
their immutable protocols; pilot books retain the parser behavior they
actually used. `learning_v3.py` supplies the corrected outer-fence parser for
the subsequent full and online preparations. `final_learning.py` prepares
the four registered full recipes. Do not regenerate a pilot or select a new
author after looking at a follow-up result.

The main study has already registered every job. These commands resume the
finite frozen schedule and the two online courses. They can run in separate
terminals; the schedule leaves ten of sixteen slots for online work until
both courses finish. Do not alter concurrency inside an active batch.

```bash
python -m experiments.ace_independent_audit.schedule run
python -m experiments.ace_independent_audit online 0
python -m experiments.ace_independent_audit online 1
```

The registered rule-repair supplement was dispatched in the five slots freed
when online order one finished. This resource-only amendment is recorded in
`rule_repair_scheduling_amendment.json`; no active batch was resized. Preparing
O1 requires all forty completed updates of the preselected online order zero.
The commands below resume supplements after the main schedule is closed;
already completed cells are retained:

```bash
python -m experiments.ace_independent_audit.rule_repairs run
python -m experiments.ace_independent_audit.adaptive_frozen prepare
python -m experiments.ace_independent_audit.adaptive_frozen run
```

## Verify and analyze

These two commands inspect only closed batches and can run during paid work.
HTTP is disabled inside exact replays. Independent compilation verifies the
returned proof against the allowed original statement. Previously certified
artifacts are reused only after matching their hashes.

```bash
python -m experiments.ace_independent_audit.verification run-completed
python -m experiments.ace_independent_audit.budget_replay run-completed
```

After active batches finish, the following command certifies the completed
checkpoint. It checks every settled receipt and proof without treating
unlaunched cells as failures. It compares only complete forty-problem
replicates and reads the already completed lower-budget replay certificates:

```bash
python -m experiments.ace_independent_audit.checkpoint
```

R1 contains one returned provider context-limit failure. Its paid prefix and
exact rejected request are reproduced offline by `terminal_failure rule_repairs`;
the original exception and cache remain unchanged. A separate certificate
retains this failed attempt and its entire cost in the eighty-cell denominator.
There is no replacement draw. The checkpoint distinguishes 1,018 normal exact
replays from one terminal-prefix/rejected-request replay. The final study
certifier retains the same distinction and the original full denominator;
it cannot silently omit this attempt.

The checkpoint reports and artifacts have separate filenames from final
results. `artifacts checkpoint` packages that evidence after the reports
are assembled. The original full-study denominator remains mandatory for
the finalizers below.

After every registered attempt and update finishes, finalize in this order:

```bash
python -m experiments.ace_independent_audit.fresh
python -m experiments.ace_independent_audit.rule_repairs assess
python -m experiments.ace_independent_audit.adaptive_frozen assess
python -m experiments.ace_independent_audit.mechanisms
python -m experiments.ace_independent_audit.economics finalize
python -m experiments.ace_independent_audit.certification finalize
python -m experiments.ace_independent_audit.study_certification
python -m experiments.ace_independent_audit.budget_replay finalize
python -m experiments.ace_independent_audit.tables
python -m experiments.ace_independent_audit.figures final
```

The six-call `learning_cache` diagnostic is separately registered and bills
the diagnostics ledger category. It changes only the cache mode for six
already saved Sol author inputs; it neither adds solver cells nor updates a
book. `learning_costs` and `book_signal` derive the associated preparation
cost and rule-provenance analyses without new API calls. Do not apply the
one-shot cache policy to the benchmark solver's reusable conversation.

Finalizers reject missing cells, unresolved costs, changed source/cache hashes,
or incomplete chronology. They do not manufacture a result for an unfinished
attempt. The main finalizer retains the exact 1,520-cell denominator; the
supplement finalizers are separate. The overall proof/receipt certification
requires all 2,044 cells.

The historical census is reconstructed from allowed individual raw cells,
not previous reports. `audit.py`, `catalog.py`, `historical_reconciliation.py`,
`historical_comparisons.py`, and `historical_proofs.py` preserve that evidence
chain. `monolithic_parser.py` and `rule_probes.py` provide zero-API diagnostics.
Normalized historical tariffs are not represented as original invoices.

## Scoped checks

```bash
python -m pytest experiments/ace_independent_audit/tests.py -q
ruff check experiments/ace_independent_audit
pyright experiments/ace_independent_audit
make agents-check
```

The required repository type check runs from the repository root:

```bash
PYTHONPATH=examples/libraries/why3py/src make pyright
```

Do not use aggregate partition checks, repricing, legacy eager-loader test
modules, or aggregate `make test` while the closed-data instruction applies.
Do not broadly format sealed solver sources after experiments start: the
certification records their exact bytes. Analysis/reporting files may be
improved without changing paid solver behavior.

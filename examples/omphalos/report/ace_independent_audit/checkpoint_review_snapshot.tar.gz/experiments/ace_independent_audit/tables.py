"""Numerical report tables derived from the complete certified study."""

from collections import defaultdict
import csv
from typing import Any

from .analysis import metrics
from .common import REPORT, read, save
from .reporting import ARM_NAMES, group_order, inputs


def csv_table(name: str, rows: list[dict[str, Any]]) -> None:
    if not rows:
        raise ValueError("Cannot export an empty table")
    with (REPORT / name).open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def interval(pair: list[float]) -> str:
    return f"[{100 * pair[0]:.1f}, {100 * pair[1]:.1f}]"


def serving(data: dict[str, Any]) -> None:
    table: list[dict[str, Any]] = []
    markdown = [
        "## Full-panel serving results",
        "",
        "Each row contains forty problems and two paid replicates. Costs",
        "include every failed attempt. Solves and cost per forty are averages",
        "over the two replicates; the underlying totals are preserved in CSV.",
        "Online rows report solver inference only; their update bills appear",
        "separately. R1 is a manual trainX diagnostic. These are reused",
        "development partitions, with no untouched confirmation claim.",
        "",
    ]
    for stage in ("train", "validation"):
        markdown += [
            "### " + stage + "X",
            "",
            "| Arm | Solved / 40 | Cost / 40 | Cost / solve | Saving vs matched control |",
            "|---|---:|---:|---:|---:|",
        ]
        for key in sorted(data["metrics"], key=group_order):
            if not key.startswith(stage + "/"):
                continue
            arm = key.split("/")[1]
            m = data["metrics"][key]
            comparison = data["comparisons"].get(key)
            row: dict[str, Any] = dict(
                stage=stage,
                arm=arm,
                description=ARM_NAMES[arm],
                n=m["n"],
                solves=m["solves"],
                mean_solves_per_40=m["solves"] / (m["n"] / 40),
                all_attempt_cost=m["cost"],
                mean_cost_per_40=m["cost"] / (m["n"] / 40),
                cost_per_solve=m["cost_per_solve"],
                requests=m["requests"],
                failed_cost=m["failed_cost"],
                baseline="",
                solve_difference_per_40="",
                saving="",
                saving_ci90_low="",
                saving_ci90_high="",
                family_saving_ci90_low="",
                family_saving_ci90_high="",
                theorem_cost_sign_flip_p="",
                leave_one_theorem_out_low="",
                leave_one_theorem_out_high="",
                practical_target="",
            )
            saving = "—"
            if comparison is not None:
                pair = comparison["theorem"]
                family = comparison["family"]
                if not pair["complete"] or not family["complete"]:
                    raise ValueError("Incomplete report comparison")
                row.update(
                    baseline=comparison["baseline"],
                    solve_difference_per_40=40 * pair["coverage_delta"],
                    saving=pair["saving"],
                    saving_ci90_low=pair["saving_ci90"][0],
                    saving_ci90_high=pair["saving_ci90"][1],
                    family_saving_ci90_low=family["saving_ci90"][0],
                    family_saving_ci90_high=family["saving_ci90"][1],
                    theorem_cost_sign_flip_p=pair["two_sided_sign_flip_p"],
                    leave_one_theorem_out_low=pair[
                        "leave_one_cluster_out_saving"
                    ][0],
                    leave_one_theorem_out_high=pair[
                        "leave_one_cluster_out_saving"
                    ][1],
                    practical_target=pair["practical_target"],
                )
                saving = f"{100 * pair['saving']:+.1f}%"
            table.append(row)
            cps = m["cost_per_solve"]
            cps_text = "—" if cps is None else f"${cps:.4f}"
            markdown.append(
                f"| {arm}: {ARM_NAMES[arm]} | {row['mean_solves_per_40']:.1f}"
                f" | ${row['mean_cost_per_40']:.4f} | {cps_text} | {saving} |"
            )
        markdown.append("")
    markdown += [
        "### Paired uncertainty",
        "",
        "Intervals are percentages. Theorem clustering retains both",
        "replicates; broader proof-method families provide a sensitivity",
        "analysis. Positive savings mean ACE is cheaper. Intervals and",
        "unadjusted sign-flip p-values describe uncertainty, not a promotion",
        "gate. The CSV also supplies leave-one-theorem-out sensitivity.",
        "",
        "| Partition / arm | Saving | Theorem 90% interval | Family 90% interval |",
        "|---|---:|---:|---:|",
    ]
    for row in table:
        if row["saving"] == "":
            continue
        markdown.append(
            f"| {row['stage']}X / {row['arm']} | {100 * row['saving']:+.1f}%"
            f" | {interval([row['saving_ci90_low'], row['saving_ci90_high']])}"
            f" | {interval([row['family_saving_ci90_low'], row['family_saving_ci90_high']])} |"
        )
    csv_table("serving_results.csv", table)
    (REPORT / "serving_tables.md").write_text("\n".join(markdown) + "\n")
    groups: dict[tuple[str, str, int], list[dict[str, Any]]] = defaultdict(
        list
    )
    for row in data["rows"]:
        groups[row["stage"], row["arm"], row["seed"]].append(row)
    replicate_rows: list[dict[str, Any]] = []
    for (stage, arm, seed), rows in sorted(groups.items()):
        m = metrics([dict(r, turns=[]) for r in rows])
        m["large_context_requests"] = sum(
            r["trace_summary"]["long_context_requests"] for r in rows
        )
        if m["n"] != 40:
            raise ValueError("Incomplete replicate in serving table")
        replicate_rows.append(dict(stage=stage, arm=arm, seed=seed, **m))
    csv_table("serving_replicates.csv", replicate_rows)


def budget() -> None:
    data = read(REPORT / "budget_replay_results.json")
    if data["scenarios"] != 4560 or data["paid_calls"] != 0:
        raise ValueError("Budget replay is not complete")
    table: list[dict[str, Any]] = []
    for key, m in sorted(data["metrics"].items()):
        stage, arm, cap_text = key.split("/")
        baseline = "B0" if arm.startswith("B") else "A0"
        same = data["metrics"][f"{stage}/{baseline}/{cap_text}"]
        full = data["metrics"][f"{stage}/{baseline}/0.1"]
        point = dict(
            stage=stage,
            arm=arm,
            stopping_allowance=float(cap_text),
            n=m["n"],
            solves=m["solves"],
            mean_solves_per_40=m["solves"] / 2,
            all_attempt_cost=m["cost"],
            mean_cost_per_40=m["cost"] / 2,
            cost_per_solve=m["cost_per_solve"],
            baseline=baseline,
            saving_vs_same_cap=1 - m["cost"] / same["cost"],
            solve_difference_vs_same_cap=(m["solves"] - same["solves"]) / 2,
            saving_vs_ordinary_ten_cents=1 - m["cost"] / full["cost"],
            solve_difference_vs_ordinary_ten_cents=(
                m["solves"] - full["solves"]
            )
            / 2,
            dominated_by_a_matched_nonace_budget=False,
        )
        controls = [
            value
            for name, value in data["metrics"].items()
            if name.startswith(f"{stage}/{baseline}/")
        ]
        point["dominated_by_a_matched_nonace_budget"] = any(
            control["cost"] <= m["cost"]
            and control["solves"] >= m["solves"]
            and (
                control["cost"] < m["cost"] or control["solves"] > m["solves"]
            )
            for control in controls
        )
        table.append(point)
    csv_table("budget_frontier.csv", table)
    save(
        REPORT / "budget_frontier.json",
        dict(
            rows=table,
            meaning="Conditional on the observed responses and cache charges. Compare both equal stopping allowances and the ordinary baseline's complete budget frontier. A joint ACE+budget gain is not automatically an ACE effect.",
        ),
    )


def run() -> None:
    data = inputs()
    serving(data)
    budget()
    print(
        "Exported complete serving, replicate, uncertainty and budget tables"
    )


if __name__ == "__main__":
    run()

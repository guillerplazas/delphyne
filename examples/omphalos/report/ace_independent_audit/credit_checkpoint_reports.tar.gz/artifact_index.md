# Evidence and reproduction index

The [short assessment](short_report.md) and [long report](long_report.md) now
include complete validation panels, both online curricula, R1's matched-budget
signal, the pilot-repeat reversal, and executable failure repairs. Their
completed-panel snapshot is distinct from the unfinished original API queue,
which stopped when account credits were exhausted at 20:27 local.
The initial user hold was revoked; its exact checkpoint reports and review
files are retained in the [snapshot](checkpoint_review_snapshot.json).
The [package README](../../experiments/ace_independent_audit/README.md) gives
commands shared by Codex and Claude Code.

## Completed development comparisons

| Artifact | Evidence |
|---|---|
| [Validation diagnosis](validation_diagnosis.json) | Seven complete 80-cell panels, exact costs, both replicates, theorem/family uncertainty, and failed-theorem sensitivity |
| [Online totals](../../experiments/campaigns/ace_independent_audit/resumption_online_complete.json) | All 400 solver attempts and 80 updates, inference versus operating cost |
| [Online chronology](online_chronology.json) | Exact preceding book, current/future task exclusion, score-before-update ordering |
| [Train budget comparisons](../../experiments/campaigns/ace_independent_audit/resumption_train_budget.json) | R1 and ordinary controls on all forty trainX tasks and both replicates, matched stopping allowances |
| [R1 cost drivers](../../experiments/campaigns/ace_independent_audit/resumption_r1_cost_drivers_0.09.json) | Paired theorem contributions to the 10.5963% matched-.09 result |
| [R1 budget economics](../../experiments/campaigns/ace_independent_audit/r1_budget_economics.json) | Preparation, payback and ten-percent total-cost threshold |
| [P1 full train](../../experiments/campaigns/ace_independent_audit/resumption_p1_train.json) | Full 80-cell short-book follow-up |
| [Pilot-repeat diagnosis](pilot_repeat_diagnosis.json) | Same twelve pilot tasks versus other 28; 48 exact initial-request pairs; all subset outcomes retained |
| [Preparation economics](preparation_economics.json) | Fixed sources, author/audit fees, book sizes, deterministic teacher work |
| [Learning cost breakdown](learning_cost_breakdown.json) | Input/output, unused writes and long-context author charges |
| [Six-call cache experiment](learning_cache_diagnostic.json) | Actual author-only input-cost saving; no book or solver replacement |
| [Rule provenance](book_signal.json) | Origins of all retained rules and source outcomes |

## Executed mechanism experiments

| Artifact | What was checked |
|---|---|
| [LCM repair](lcm_repair_certification.json) | Original theorem compiles and passes ordinary unassisted bridge in 1.69s |
| [Context-expansion repairs](context_repair_certification.json) | Two original failed candidates close with a narrow algebraic ending |
| [Goal-flood probe](goal_flood_probe.json) | 192-goal proposal, bounded/unassisted execution |
| [Goal-flood timing](goal_flood_timing.json) | Actual completed attempt: API versus local intervals and next-prompt expansion |
| [Invalid witness proof](goal_flood_witness_certification.json) | Compiled duplicate witness; failed concrete probe preserved |
| [Missing dependency repair](pilot_dependency_repair.json) | One omitted symmetry equation closes the saved second proposal |
| [R1 prime-rule dossier](r1_prime_dossier.json) | Concentration of familiar-workload saving in one theorem; unchanged A2 rule |
| [Teacher gain dossier](teacher_gain_dossier.json) | All four gained B2 outcomes and rule provenance, without invented bullet causality |
| [Output token categories](validation_token_categories.json) | Reasoning versus other output across seven complete panels |
| [Capped-output census](output_repetition_diagnosis.json) | All 27 capped replies; 23 empty legacy parses; one valid recovered proof and 26 retained failed checks |
| [Provider retrieval check](output_repetition_provider_check.json) | Same 91,617-character repeated message and usage retrieved from the stored response |
| [Parser/controller replay](parser_replay_certification.json) | One extracted valid proof accepted by the actual controller at all four caps with zero API calls |
| [Figures](figures/README.md) | Standalone PNG/SVG/PDF exports from audited numbers |

These diagnostic repairs never replace a measured failed outcome or enter the
frozen playbooks. They establish executable mechanisms and precise repairs,
not autonomous benchmark success.

## Accounting and implementation

The [timeout reconciliation](billing_recovery_proposal.md) retains the failed
outcome and full unknown-request liability. Its
[authorization clarification](../../experiments/campaigns/ace_independent_audit/billing_recovery/authorization_clarification.json)
records use of the already granted API continuation, withdrawing an unnecessary
extra permission question without inventing a new user reply. Its
[applied analysis check](../../experiments/campaigns/ace_independent_audit/billing_recovery/applied_analysis_check.json)
reconciles the actual 100-cell batch and exposes the timeout interval.
The general guard remains active for later unknown requests. Reserved liability
is never called an exact invoice.

The [returned inventory](../../experiments/campaigns/ace_independent_audit/resumption_returned_inventory_20260919.json)
records the 1,524-returned-attempt checkpoint: 1,520 exact normal replays, three
known terminal failures, 921 distinct compiled proofs covering 1,138 solves,
and the then-prepared timeout prefix. The applied reconciliation subsequently
certifies that timeout separately. The later
[quota preparation](../../experiments/campaigns/ace_independent_audit/quota_recovery/preparation.json)
preserves the credit-interrupted A2 trajectory and four exact prefix replays.
[Returned batch-six certification](returned_part06_certification.json)
covers its other 99 completed cells, including every lower-budget scenario
and independent proof compilation. There are now 1,623 completed attempts,
one administratively interrupted trajectory and 420 unlaunched attempts.
Full-study finalizers still require all 2,044 original solver attempts.

The [current credit checkpoint inventory](quota_checkpoint_inventory.json)
reconciles all 1,623 completed attempts: 1,619 normal exact replays and four
terminal-prefix certificates, with 989 distinct compiled proofs covering
1,229 solved outcomes. Its [receipt certificate](quota_checkpoint_receipt_certification.json)
independently reprices every returned provider response and retains the
separate unknown timeout invoice in the $307.81500175–$308.03739447 total
research-cost interval. The incomplete credit-interrupted prefix remains
identified separately. Neither checkpoint is a full-study verdict.

The [exact-statistics regression](../../experiments/campaigns/ace_independent_audit/cost_bounds_exact_regression.json)
checks 27 prior comparisons remain identical after adding invoice intervals.
The [initial source and contracts](../../experiments/campaigns/ace_independent_audit)
record exact jobs, immutable books and 100 unchanged main-study source files.

## Preserved historical reconstruction

The [audit inventory](audit_inventory.json) selects permitted individual raw
cells, with [completion record](audit_completion.json),
[descriptive catalogue](all_variants.csv), [solver panels](historical_solver_panels.csv),
[learning roles](historical_learning_roles.csv), and
[matched comparisons](historical_matched_comparisons.csv).
[Continuation reconciliation](historical_continuations.json) identifies exact
replayed prefixes; [reconciled panels](historical_reconciled_panels.csv) remove
duplicate recorded calls. [Original-loop comparisons](historical_original_comparisons.json)
remain separate from later grounded-agent contracts.

[Historical proof certification](historical_proof_certification.json) compiles
all 3,485 distinct returned scripts, covering 4,953 solved permitted cells.
The [monolithic parser check](monolithic_parser_certification.json) evaluates
all 196 saved replies without model calls. [Ten tactic probes](rule_probe_certification.json)
and [six rule-repair probes](rule_repair_certification.json) test learned claims
in executable Rocq; incorrect draft imports remain preserved and excluded.
The large raw census stays local with per-cell hashes.

## Preserved initial checkpoint and raw corpus

[Checkpoint results](checkpoint_results.json), [cells](checkpoint_cells.json),
[replicate tables](checkpoint_tables.md), [mechanisms](checkpoint_mechanisms.json),
[budget results](checkpoint_budget_results.json),
[receipt certification](checkpoint_receipt_certification.json) and
[receipt CSV](checkpoint_settled_receipts.csv) retain the original 1,019-attempt,
$282.32564758 settled checkpoint. Their findings are historical checkpoints,
not current full-panel conclusions. The [checkpoint manifest](checkpoint_artifact_manifest.json)
and [raw inventory](checkpoint_raw_artifact_hashes.jsonl) preserve its evidence.

Only this study's trainX/validationX campaign tree is inventoried. `runs/` and
`responses/` retain paid caches and raw provider records; `role_inputs/`,
`learning_events/`, `online_scores/` and `online_events/` retain learning
provenance. `verification/`, `budget_replay/` and `kernel/` retain independent
checks; `billing_recovery/` preserves the timeout and authorization records,
and `quota_recovery/` preserves the interrupted trajectory before continuation.
No credential is copied into the review bundle. Closed evaluation partitions
and protected challenge data remain excluded.

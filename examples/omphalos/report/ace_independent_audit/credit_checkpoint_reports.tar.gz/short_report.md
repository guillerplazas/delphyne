# ACE investigation — short assessment

September 19, 2026. **We have a 10% cost signal on trainX, but the completed validation results are more modest.** The experiments now explain why: useful ACE advice shortens some successful proofs, while expensive failed searches, incorrect rules and repeated output consume the saving.

The clearest signal is **R1, the Sol playbook with three verified rule repairs**, using Luna to solve. With the same $0.09 stopping allowance for both pipelines, it solves **66/80 for $1.52290**, versus ordinary non-ACE's **62/80 for $1.70339**: **10.60% cheaper with four more solves**. This uses all forty trainX problems and two replicates. It is a familiar-workload result from exact saved-response controller replay; its uncertainty is broad, and one theorem supplies 80.9% of the net saving. It does not yet establish the same benefit on other problems.

On the seven completed validationX panels, **teacher-evidence B2** is the most promising ACE comparison: **52/80 solves for $1.80229**, versus its matched ordinary control's **49/80 for $1.86280**. That is **3.25% cheaper**. B2 also costs **24.82% less than B1**, the comparable ACE book without teacher evidence. The stronger ordinary assisted pipeline remains a necessary reference: it solves 56/80 for $1.75434.

The short P1 book's initial **57.41% pilot saving did not repeat**. On the same twelve problems in two new replicates, it becomes 48.63% more expensive and loses five solves, despite identical initial requests. Its full train result costs 1.77% more; its validation saving is 2.79% with too many lost solves. It should no longer lead the investigation merely because its pilot looked excellent.

Several causes are now tested, not guessed:

- A2 is cheaper on problems both agents solve, but its failures consume **80.92% of its bill**. One large-number LCM problem erases its whole aggregate gain. A representation-aware repair closes that original theorem in **1.69 seconds** through the ordinary checker.
- Two nearly finished proofs generate **3.33 million characters of feedback** by expanding a large product. A three-tactic ending closes both original proofs. Existing goal caps leave the error-message field unbounded.
- B1 has twelve replies that repeat proofs until the output limit; B2 has two. Their fee difference explains **68.78% of the B1–B2 cost gap**.
- The parser discards a valid baseline proof. Correct extraction saves one request in an actual controller replay, and recovers that solve under the $0.05 allowance. This is a shared infrastructure repair, not ACE credit.

**Budget control already achieves an accepted validation trade-off:** ordinary non-ACE costs **11.86% less** at $0.05 than at $0.10, losing only one solve out of eighty. ACE comparisons must also give their ordinary controls the same lower allowance.

The best direction is verified, precise repair advice combined with control of expensive failed trajectories. Larger authors remain confined to playbook preparation; Luna remains the solver. Preparation is separate: R1's paid preparation is $21.16, and continuous online strong-model updates are expensive. The long report gives amortization and all limitations.

**Current status:** 1,623 of 2,044 registered solver attempts are complete. The API account then exhausted its credits. One additional attempt is preserved after eight paid responses; 420 are unlaunched. Its exact continuation is checked and ready when account access is restored. Settled research spending is $307.81500, plus at most $0.22239 for a separate timed-out request whose failed outcome and liability are retained. No authoring calls remain. No extra experiments or replacement model draws were added; only trainX and validationX were used.

[Long report](long_report.md) · [Evidence index](artifact_index.md)

# Independent ACE investigation — resumed assessment

September 19, 2026. **The API account exhausted its credits at 20:27 Europe/Berlin.** The study has 1,623 completed solver attempts, one additional trajectory interrupted after eight paid responses, and 420 unlaunched attempts. The interrupted trajectory's exact prefix is preserved for continuation after account access is restored; it is not scored as a theorem failure. A separate earlier timeout has an unknown invoice bounded by its retained $0.22239272 reservation. This report separates complete panels from the unfinished registered scope. The initial checkpoint, including its original reports, is preserved in the [review snapshot](checkpoint_review_snapshot.json).

There are useful signals, with different meanings. **R1, the Sol book with three verified rule repairs, reaches 10.60% lower inference cost on all forty trainX problems and two replicates at a matched $0.09 stopping allowance, with four additional solves out of eighty.** This is a familiar-workload, conditional controller result, not an untouched transfer result. On the seven completed validationX panels, B2 is the strongest playbook comparison: 3.25% lower cost and three additional solves against its matched ordinary control. It is 24.82% cheaper than B1, its comparable ACE recipe without teacher evidence. The selected short-book pilot does not retain its large initial saving in the full benchmark.

The main diagnosis is specific: successful ACE paths can get shorter, while failed paths generate expensive feedback and repeated output. Strong authors also turn unverified hypotheses into incorrect rules. Executable repairs below show that several costly failures have short valid solutions; the limitation is the measured learning and control procedure, not an established impossibility of solving these problems economically.

## Completed scope and accounting

A solver attempt is one problem, variant and replicate, containing up to many API requests and proof checks. The 1,520 main attempts are not 1,520 different algorithm designs. The main design comprises the frozen books, shared ordinary controls, and online curricula described below.

| Work | Returned | Registered |
|---|---:|---:|
| Main benchmark, including shared online controls | 1,259 | 1,520 |
| Three-rule R1 diagnostic | 80 | 80 |
| Adaptive frozen O1 follow-up | 0 | 160 |
| Source collection | 80 | 80 |
| Author-book pilot | 204 | 204 |
| Total completed solver attempts | **1,623** | **2,044** |

Of the 1,259 completed main attempts, 1,258 have exact settled costs; the remaining B1 trainX attempt is the timeout, separately reconciled with its invoice interval. Both online curricula and all eighty updates are complete. P1's two full development panels are complete. The remaining work is one exact-prefix continuation, 100 original frozen cells, 160 S1 cells, and 160 O1 cells: 421 original attempts still lack a final outcome. O1's preselected final order-zero book is already frozen: 58 rules and 19,679 characters. There are no remaining paid author or learning calls. No completed outcome or successful model response is replaced.

The settled research bill is **$307.81500175 across 22,929 settled requests**, including the interrupted trajectory's $0.01360583 prefix and its zero-charge credit rejection. With the separate unresolved timeout, the full bill is in **[$307.81500175, $308.03739447]**. The upper endpoint is retained liability, not a measured invoice.

| Settled category | Cost | Requests |
|---|---:|---:|
| Luna solving, including sources and author pilots | $34.92234201 | 21,837 |
| Playbook learning, audits and author selection | $270.72092774 | 1,086 |
| Six author-cache diagnostics | $2.17173200 | 6 |

The credit interruption affects A2 trainX `amc12b_2004_p3`, replicate one. Request nine returned HTTP 429 with `credit_balance_exhausted`, after eight successful responses. This is account-level administrative censoring, distinct from the earlier timeout or context-limit failures. Four HTTP-disabled replays consume every saved model/compute entry and restore the original transport state before reaching the identical rejected request. The other 99 cells in its batch pass exact replay, lower-budget replay and independent proof compilation. The [quota preparation](../../experiments/campaigns/ace_independent_audit/quota_recovery/preparation.json) records these checks. The continuation adapter preserves that prefix because the generic launcher retry would otherwise erase the active cache and resample the trajectory. Paid dispatch remains paused pending account access; no full-panel result is inferred from the interrupted cell.

B1's trainX `mathd_algebra_185` replicate zero made 23 successful calls costing $0.03731910. Request 24 timed out after 600 seconds, with no returned response ID. The entire $0.22239272 reservation remains retained. Its cell cost is therefore [$0.03731910, $0.25971182], and its outcome remains failed. Four HTTP-disabled controller replays reach the exact saved terminal request. The other 99 outcomes in its batch are certified.

The current key cannot read organization usage: the read-only usage query returns 403 with missing `api.usage.read`. The documented Responses retrieval method requires the missing response ID; retrieving the preceding response does not recover the next one. See the [official retrieval reference](https://developers.openai.com/api/reference/python/resources/responses/methods/retrieve) and [organization usage reference](https://developers.openai.com/api/reference/python/resources/admin/subresources/organization/subresources/usage). The [applied recovery](billing_recovery_proposal.md) keeps this one receipt explicitly bounded, retains its full liability and failed outcome, and preserves the guard for every later unknown bill. An additional per-receipt permission question was unnecessary given the existing API continuation and was withdrawn. The authorization record identifies the existing instruction; it does not claim a new user reply. No paid scope or capacity was increased. All validationX results and the completed R1/online comparisons below have exact settled costs.

## Seven complete validationX panels

Each row contains the same forty problems and two independent paid replicates. Costs include failures. A0 is the original ordinary agentic pipeline with its existing assisted checker; B0 checks the submitted script without supplying completion tactics. ACE receives the same two tools, limits and checker as its matching ordinary control.

| Arm | Solves / 80 | Total inference cost | Cost / solve | Saving vs matched ordinary |
|---|---:|---:|---:|---:|
| A0: ordinary assisted | 56 | $1.75434 | $0.03133 | reference |
| A1: historical X5 book | 57 | $2.00053 | $0.03510 | −14.03% |
| A2: full Sol book | 52 | $1.91452 | $0.03682 | −9.13% |
| P1: short Sol pilot book | 50 | $1.70541 | $0.03411 | +2.79% |
| B0: ordinary plain | 49 | $1.86280 | $0.03802 | reference |
| B1: plain-source Sol book | 49 | $2.39745 | $0.04893 | −28.70% |
| B2: teacher-evidence Sol book | 52 | $1.80229 | $0.03466 | +3.25% |

P1 loses six solves, or three per forty on average, exceeding the accepted one-to-two-problem trade-off. B2 gains three versus B0 and saves 3.25%, but does not reach 10%. Ordinary A0 itself is cheaper and solves seven more attempts than B0. The plain comparison isolates ACE under an unassisted checker; it must not be selected merely because it makes ACE look better than the stronger ordinary pipeline.

The paired 90% theorem-cluster savings intervals are A1 [−41.25%, +8.17%], A2 [−42.02%, +17.44%], P1 [−18.76%, +19.45%], B1 [−58.21%, −4.08%] and B2 [−23.95%, +24.94%]. They express substantial uncertainty, not a per-replicate veto or an impossibility claim. [Complete validation diagnosis](validation_diagnosis.json) includes both replicates, family sensitivity, outcomes and theorem-level contributions.

![Seven complete validation panels: both ordinary baselines remain explicit, and capped-call fees are shown separately.](figures/completed_validation_diagnosis.png)

### Teacher evidence improves B2 relative to B1, but the ordinary comparator still matters

B2 costs $1.80228558 versus B1's $2.39744954: **24.8249% less**, with 52 versus 49 solves. Its theorem-cluster 90% interval is [5.98%, 39.87%], with unadjusted two-sided sign-flip p=0.0533; broader family sensitivity is [7.09%, 40.29%]. Excluding both replicates of the theorem with B2's context-limit failure leaves a 23.32% saving, interval [4.05%, 39.11%], p=0.0813. The original eighty-cell comparison remains the headline.

B2 gains four individual outcomes against B0 and loses one. The gains use a preserved recursive fold in a product inequality, a trigonometric factorization, square-root algebra with nonzero denominators, and Fibonacci periodicity. One gained solve is more expensive than its corresponding failed baseline attempt. Similar relevant rules already exist in B1, so matching proof text to a bullet cannot prove that a particular teacher lesson caused a gain. The [gain dossier](teacher_gain_dossier.json) retains all four gains and their provenance.

A sharper cost mechanism is repeated output. B1 emits 1,069,842 output tokens versus B2's 607,811. Non-reasoning output accounts for 421,773 of that 462,031-token difference. Twelve B1 replies hit the 32,768-token output limit, compared with two B2 replies. Their fees are $0.49004520 and $0.08070508; the $0.40934012 gap accounts for **68.78% of the total B1–B2 cost difference**. This is a measured cost decomposition, not money recovered after the fact.

### Why the full assisted book costs more

Across all eighty validation attempts, A2 increases input billing from $0.94872761 to $1.12521449 (+$0.17648688), while output billing falls from $0.80561340 to $0.78930720 (−$0.01630620). The net increase is $0.16018068. Mean initial input grows from 3,810 to 8,907 tokens. Its cached fraction actually improves, from 90.32% to 92.90%, so cache-hit percentage alone does not diagnose the regression.

Among the 52 attempts both A0 and A2 solve, A2 costs $0.365293 versus $0.48860314 and uses 292 versus 385 requests. Among the 24 attempts both fail, A2 costs $1.32525683 versus $1.16181794. The four lost solves cost A2 $0.22397186 versus A0's $0.10391993. **ACE helps on shared successes, but expensive failures and lost successes erase that saving.** A2's failures consume 80.92% of its total spend, versus 66.23% for A0.

Both replicates of `mathd_numbertheory_37` fail. Together they cost A2 $0.30433091 versus A0's $0.09159039, although A2 makes 56 requests versus A0's 64. This theorem's $0.21274052 excess exceeds A2's entire aggregate regression. Removing both matched theorem replicates leaves A2 3.16% cheaper, still with four fewer solves; that sensitivity cannot replace the full-panel result. A2's peak request reaches 512,493 input tokens. One failed arithmetic expansion produces 1,705,029 characters of verifier feedback, far larger than the book itself.

## A concrete 10% signal on trainX, and what produces it

R1 changes three incorrect or overbroad A2 rules after executable checks. Its full trainX result at the original $0.10 allowance is **66/80 solves for $1.58172861**, versus ordinary A0's **63/80 for $1.71479723**: 7.76% lower cost and three additional solves.

The registered lower-budget experiment replays the actual controller on those same responses. At **$0.09 for both pipelines**, R1 retains 66 solves and costs **$1.52289570**. A0 has 62 solves and costs **$1.70339228**. The saving is **10.5963%**, with four additional solves. The practical target is met on this familiar workload. The 90% interval is [−9.16%, +27.81%], p=0.4225; it is not a statistically established general effect. Leave-one-theorem-out savings range from 2.22% to 14.70%.

This result is not just a nominal budget label. Reducing R1 from $0.10 to $0.09 avoids three requests on two still-unsolved attempts, saving $0.05883291. A0 avoids one request but loses a solve on `aime_1988_p3`. The [R1 transition](../../experiments/campaigns/ace_independent_audit/r1_budget_transition.json) and [baseline transition](../../experiments/campaigns/ace_independent_audit/baseline_budget_transition.json) identify those exact cells.

One familiar theorem, `amc12_2000_p6`, accounts for $0.14608251, or **80.9% of the net $0.18049658 saving**. A0's two replicates use 23 and 20 requests; R1 uses two and five. R1's relevant prime-divisor rule already existed unchanged in A2 and was learned from that same theorem. Therefore this concentration supports familiar-workload reuse, but cannot be attributed to the three repaired rules. The [prime-divisor dossier](r1_prime_dossier.json) records the actual trajectories. The direct full-panel A2–R1 comparison remains within the original unlaunched main scope; partial A2 train results are not substituted for it.

R1's retained context-limit failure does not manufacture the win. Excluding both replicates of its affected theorem raises the matched $0.09 saving to 12.61%. All eighty attempts remain in the primary result. The measured R1 recipe includes manual review and is not advertised as autonomous ACE.

## Ordinary budget control already gives a useful result

The complete validationX ordinary A0 budget replay reduces total cost from **$1.75434101 to $1.54628491**, or **11.86%**, when the allowance changes from $0.10 to $0.05. It loses one solve out of eighty, 56 to 55, within the user's accepted trade-off. B0 similarly saves 15.69%, from $1.86279672 to $1.57059862, losing one solve, 49 to 48.

| Validation arm | $0.05: solves / cost | $0.075: solves / cost | $0.09: solves / cost | $0.10: solves / cost |
|---|---:|---:|---:|---:|
| A0 | 55 / $1.54628 | 56 / $1.71199 | 56 / $1.75434 | 56 / $1.75434 |
| B0 | 48 / $1.57060 | 49 / $1.74626 | 49 / $1.83443 | 49 / $1.86280 |
| B2 | 50 / $1.56854 | 51 / $1.69704 | 52 / $1.79381 | 52 / $1.80229 |
| P1 | 49 / $1.47303 | 50 / $1.60907 | 50 / $1.68646 | 50 / $1.70541 |

B2 at $0.05 is 15.80% cheaper than B0 at $0.10 and solves one more attempt. But B0's own lower allowance captures almost all that cost saving: B2 versus B0 at the same $0.05 saves just 0.13%. A joint ACE-plus-budget improvement and an ACE-specific cost improvement are different estimands. P1's lower cost at $0.05 still loses too many solves against A0 to meet the requested trade-off.

These are deterministic controller experiments conditional on the recorded responses and cache charges, with no new model draws. A nominal spending allowance is checked between requests and can be exceeded by a crossing response; costs are never clipped to the nominal cap. The 20:00 snapshot has 2,997 certified lower-budget scenarios over 999 returned frozen cells; the completed timeout reconciliation adds its three lower-cap scenarios, bringing this returned set to 3,000 scenarios over 1,000 cells.

## The short-book pilot did not reproduce its initial advantage

P1's original twelve-problem pilot solved 11/12 versus 9/12 and saved 57.41%. Its full trainX follow-up instead solves **59/80 for $1.74508150**, versus ordinary A0's **63/80 for $1.71479723**: 1.77% more cost and four fewer solves. Its full validation result is the 2.79% saving with six fewer solves above.

The failure is visible even on the same twelve pilot problems. Across their two new replicates, P1 solves 16/24 for $0.56653286; A0 solves 21/24 for $0.38117011. P1 is **48.63% more expensive**, with five fewer solves. All 48 corresponding initial requests match the original pilot requests exactly. This directly rejects an explanation based only on changing the problem set or initial prompt. The new draws and subsequent trajectories differ; pilot selection favored an unusually good observed sample.

On the other 28 train problems, P1 does save 11.63% and gains one solve, but selecting that favorable subset would discard the observed reversal on the pilot set. The [complete repeat diagnosis](pilot_repeat_diagnosis.json) preserves every subset and raw source hash. Compact context remains a reasonable mechanism to study; the actual P1 book is no longer justified as the lead full-panel candidate by its selected pilot alone.

## Both online curricula are complete

Every current score was committed before learning from that task. The two curricula have 400 solver attempts including shared ordinary controls, with eighty completed updates. The [chronology certificate](online_chronology.json) verifies empty starting books, exact preceding states and train-only learning evidence.

| Pipeline | Solves / 80 | Solver inference | Learning updates | Operational total |
|---|---:|---:|---:|---:|
| A0 | 63 | $1.71480 | — | $1.71480 |
| online A2 | 64 | $1.62155 | $40.84603 | $42.46759 |
| B0 | 61 | $1.81116 | — | $1.81116 |
| online B1 | 64 | $1.73315 | $53.88801 | $55.62116 |
| online B2 | 64 | $1.79180 | $56.46660 | $58.25840 |

Solver-only savings are 5.44%, 4.31% and 1.07% respectively. These are promising directions in cost and coverage, but not 10% serving-cost results; frequent strong-model updating dominates total operating cost on this workload. The theorem-cluster intervals all cross zero. Because each learned state depends on earlier tasks, two order realizations are also not forty independent learning experiments. O1 evaluates the already frozen final book separately from the cost of updating after every served task.

## Executable diagnoses of the expensive failures

These are local mechanism experiments. They keep the recorded benchmark outcomes, frozen books and learning inputs unchanged. A hand-repaired proof demonstrates a correct repair route, not that Luna would autonomously discover it.

### Large-number LCM: preserve the representation

For `Nat.lcm 9999 100001 = 90900909`, the paid trajectory already established the gcd and division facts. Expanding unary multiplication then caused enormous proof-state text. Keeping that prefix, importing `DecimalNat` inside the proof, normalizing the structural decimal representation and applying `nia` closes the original theorem. Independent compilation takes **1.45 seconds**; the actual ordinary unassisted bridge accepts it in **1.69 seconds**, with no automatic completion, under the original tactic limits and 4 GB worker limit. [LCM repair certificate](lcm_repair_certification.json).

The meaningful lesson is not a broad instruction to increase context or spend more reasoning. It is a representation-specific repair: normalize compact decimal structure before invoking arithmetic, retaining the verified gcd/division work. This directly diagnoses the theorem that erased A2's aggregate savings.

### A nearly finished induction became a multi-megabyte error

P1 and B2 both reach a valid induction on validationX `amc12a_2008_p4`, then end with `cbn in H; exact H`. That reduction expands a 501-factor product. Their feedback reaches 3,329,613 and 3,329,453 serialized characters; the error message alone contributes about 2.22 million characters. The next provider request is rejected for context length.

Replacing just the final two tactics with `eapply eq_trans; [exact H |].`, then `rewrite INR_IZR_INZ.` and `ring.` compiles both original proof candidates in **0.82 and 0.79 seconds**. [Context repair certificate](context_repair_certification.json). The three retained context-limit failures, including R1's separate case, keep their paid prefixes and failed outcomes. Their rejected calls cost zero; none is replaced by a favorable draw.

The implementation's goal caps bound rendered remaining goals but do not bound `error_message`. Capping only the number of displayed goals therefore cannot prevent this failure. Any feedback bound must cover the whole serialized payload while preserving the full checker result. The diagnostic repair additionally avoids generating the huge term at all.

### A goal flood wastes local work and creates later API cost

P1's validation `amc12a_2020_p21` replicate zero proposes a list of 192 values, containing only 48 distinct values repeated four times, for a `NoDup` argument. Its uniqueness obligation is false; a symbolic duplicate witness is independently compiled. A first concrete inversion attempt overflowed the stack and is preserved as a failed probe.

The unassisted check exposes 192 goals in 1.52 seconds. In the paid assisted trajectory, the interval after this reply and before the next API dispatch is **973 seconds outside the API**. The full worker lasts 2,102.72 seconds; API requests account for 136.44 seconds. The rest must not be described as model latency. The next input jumps from 16,798 to 110,412 tokens, with 236,130 feedback characters. The worker eventually fails after 29 requests and $0.10250013. [Timing and proof evidence](goal_flood_timing.json), [compiled duplicate witness](goal_flood_witness_certification.json).

![One incorrect list construction increases local proof work and subsequent prompt size.](figures/goal_flood_trace.png)

### Repeated fenced proofs are sometimes parsed as an empty proof

All **27** capped replies in the seven completed validation panels are examined. Twenty-five repeat one identical complete typed proof 26–94 times; the other two repeat several different blocks. The legacy overlapping code-fence extractor returns an empty string in **23/27**, despite complete proof blocks being present. A closing fence is treated as another opener, and the blank gap before the next block becomes the last match.

The local replacement selects an explicitly typed, complete Rocq/Coq block. All 27 extracted candidates are independently compiled: **one passes and 26 fail**. The failed checks remain reported. A read-only retrieval of one B1 response confirms that its 91,617 characters and forty repeated proof blocks are byte-identical to the provider's stored message. The repetition is present in a single provider response, rather than being introduced by concatenating local requests. [Repetition diagnosis](output_repetition_diagnosis.json), [provider check](output_repetition_provider_check.json).

The valid discarded proof belongs to ordinary A0 on `imo_1964_p2`, replicate one. Its original run finishes after sixteen requests for $0.07685063. Correcting only the extraction of reply fifteen, with earlier responses fixed, makes the actual controller and local Rocq check finish after fifteen requests for **$0.06716406**, saving the following **$0.00968657** request. The same HTTP-disabled test succeeds at $0.10, $0.09, $0.075 and $0.05. At $0.05, the original recorded controller failed at that same $0.06716406 cost; corrected extraction recovers the solve without extra spending. [Parser/controller certificate](parser_replay_certification.json).

The already emitted 32,768 tokens are still fully charged. This repair is shared solver infrastructure, not ACE credit. The diagnostic does not replace outcomes or simulate all future feedback from a generally changed parser. The active paid source is frozen; the tested local extractor and replay are supplied without changing the remaining comparison mid-study. A generic stdlib repair lies outside the authorized edit scope and is documented as a suggestion.

### A missing dependency, rather than more broad proof search

On trainX `aime_1988_p8`, P1's second proposal already had seven recurrence equations. It omitted one required symmetry fact. Adding only `pose proof (Hsym 10%nat 4%nat P10 P4) as H11.` before the existing simplification and `nra` compiles the original candidate. The paid trajectory instead exhausted 32 requests. [Dependency repair](pilot_dependency_repair.json). This supports recording the exact prerequisite chain and verified repair, rather than merely recommending an arithmetic tactic.

## What is being reproduced

The thesis target is **at least 10% lower total inference cost than the equivalent ordinary agentic pipeline**, allowing up to two fewer solved problems per forty on average. Cost includes unsuccessful attempts. Learning and preparation are reported separately for a frozen playbook, and included in operating cost for online learning. A coverage improvement is also valuable; there is no requirement that every replicate individually avoid losing a problem.

This is an adaptation of ACE to Rocq, rather than an exact reproduction of its original benchmark. The local reference is [ACE, version 3](../../papers/2510.04618v3.pdf), also available [from the authors on arXiv](https://arxiv.org/abs/2510.04618). Section 4.1 distinguishes two experiments:

- Offline: learn the context on training problems, freeze it, and evaluate on other problems.
- Online: solve the current problem with the current context, record its score, then learn from that problem before proceeding. All compared methods see the same order.

Therefore **benchmarking trainX is appropriate**. A frozen book tested on its training problems measures familiar-workload reuse. An empty-start online curriculum measures performance before learning from the current sample. These are different claims and are reported separately. ValidationX measures development transfer; its repeated historical use means it is not an untouched confirmation set. No closed evaluation partition, protected challenge problem, or mixed results artifact was opened for this investigation.

The paper's main experiments use the same DeepSeek-V3.1 model for Generator, Reflector, and Curator, with maximum five epochs and five reflection rounds (§4.2). Its fine-grained cost study uses one epoch and one reflection round (Appendix A.3). Its stronger-Reflector ablation varies only that role: FiNER accuracy is 70.7 for the base model, 76.6 with GPT-OSS reflection, 78.3 with DeepSeek reflection, and 78.5 with GPT-5.1 reflection (Table 16). Our scaling experiment keeps **Luna as the solver** and varies the models used for reflection, curation, and terminal auditing together. It tests the authorized stronger-author recipe, not the paper's isolated Reflector ablation.

The paper does not establish a universal 10% serving-cost reduction against ordinary ReAct. Table 14 reports 27,460,411 input tokens, 289,802 output tokens, and 2,430 rollouts for Base ReAct, versus 58,623,267, 270,652, and 2,354 for ACE over 160 evaluation queries. Its printed percentage comparisons are against GEPA. The prominent adaptation savings in Table 4 are also against GEPA or Dynamic Cheatsheet. The 82.6% figure in §4.7 is **input-billing savings from caching relative to charging raw input tokens**, not total-cost savings against the ordinary agent. These distinctions determine the right denominator; they do not invalidate the thesis objective.

## Experimental contracts

All new benchmark solving uses Luna, medium reasoning, the Responses API, a 32-request allowance, a $0.10 stopping budget, and a 32,768 output-token limit. The two tools are `ReadSkill` and `SearchRocq`. The current problem's informal proof sketch and definitions are available, and the original two fixed tool-use demonstrations are retained. The baseline is therefore not theorem-only prompting. Empty ACE context renders exactly the ordinary agentic system and instance prompts; an offline contract test verifies this equality.

| Arm | Solver/checker | Playbook preparation |
|---|---|---|
| A0 | Original assisted verifier | No playbook |
| A1 | Same as A0 | Historical X5, rendering version 2 |
| A2 | Same as A0 | Forty fixed assisted trajectories; Sol authors; five terminal audit batches |
| S1 | Same as A0 | Same trajectories/order/procedure as A2; Luna authors |
| P1 | Same as A0 | The actual eleven-bullet Sol book selected by the eight-source author pilot |
| B0 | Plain verifier | No playbook |
| B1 | Same as B0 | Forty fixed plain trajectories; Sol authors; five terminal audit batches |
| B2 | Same as B0 | Same plain trajectories, augmented with training-only automatic completion evidence |
| R1 | Same as A0 | A2 with three manually audited tactic claims repaired; trainX diagnostic only |
| O1 | Same as A0 | Final book from the first adaptive online curriculum, frozen after forty updates |

The assisted verifier can supply closing tactics. The plain verifier checks the submitted proof and supplies no completion. B2's extra completion work happens **after collecting a training trajectory** and never improves a benchmark score directly. The A and B comparisons each have their own matching non-ACE control. The comparison A0 versus B0 studies the effect of assistance itself.

The initial frozen matrix contains eight arms × forty problems × two replicates × two partitions: 1,280 attempts. Three additional online ACE arms each run forty problems in two independently shuffled trainX orders: 240 attempts. Their no-ACE controls are the same 160 trainX A0/B0 attempts already included in the frozen matrix. That study contains **1,520 attempts**, with no duplicate controls. The original core is 1,200; S1 and P1 are separately registered 160-attempt follow-ups. Two subsequent diagnostics add eighty R1 trainX cells and 160 O1 trainX/validationX cells, reusing the same controls. Source collection adds eighty cells and the author pilot adds 204, for **2,044 registered solver cells overall**. Deterministic cache replays and synthetic tactic probes are separate checks, not extra independent benchmark samples.

The `seed0` and `seed1` names identify independent paid replicates and online orders; they are not a promise of deterministic provider seeding. Pairing matches theorem and replicate. For complete pooled panels, confidence intervals resample forty theorem clusters, retaining both replicates together; a second analysis uses broader proof-method families. The earlier single-replicate checkpoint is preserved separately. The proof-method families are deliberately conservative groups, not claims that all their members are duplicate statements. None of the eighty allowed statements was an exact duplicate under the inspected numeral/single-letter normalization.

The practical target is evaluated separately from statistical support. A 90% interval and a two-sided sign-flip result describe uncertainty; neither is a veto on an exploratory follow-up. Selection among several candidate books makes the author pilot exploratory, even when its unadjusted interval is favorable. The reports show both the complete cost/coverage trade-off and individual problem contributions.

### Important differences from the paper

The full offline preparation uses fixed source trajectories to isolate author and teacher changes. Its Generator does not solve each subsequent training problem with the evolving book. The online track separately tests that interaction. Consequently, helpful/harmful tags in fixed-source preparation are retrospective judgments about compatibility with a trace, not direct observations that the Generator used an evolving bullet.

The implementation uses deterministic incremental ADD merges with lexical deduplication and source-linked terminal revisions. It does not reproduce the paper's embedding-based deduplication or Generator-side bullet attribution. The nominal book cap is a 6,000-token **character-based estimate**, not an exact tokenizer limit. No full-training ADD reached that cap, and lexical deduplication merged zero bullets in each of the four full recipes. Terminal auditors receive checks, returned scripts, reflections, and deltas grouped into five batches of eight sources. Reflectors and curators receive the fuller version-2 evidence, including the informal sketch and visible tool conversation. These input contracts must not be described as identical.

P1 versus A0 changes only learned context at inference. P1 versus A2 compares complete preparation recipes: source count, curriculum order, and terminal refinement all differ. A favorable P1 result alone is not a causal estimate of shortening a forty-source book.

O1 addresses the distinction between fixed-source learning and adaptive training directly. It takes the final assisted book from online order zero, selected before either curriculum finished, and evaluates it as a frozen artifact. This is a one-epoch adaptive Generator/Reflector/Curator preparation recipe. Its comparisons with A2 or P1 include differences in source trajectories, order, and terminal auditing; they do not isolate only Generator adaptation. R1 is a manual rule-quality intervention, not an autonomous learning recipe. S1, P1, R1, and O1 reuse earlier compatible controls and were dispatched in later blocks, so their comparisons also retain temporal and provider-cache limitations. Raw-token repricing is reported as a sensitivity analysis, not as a simulated uncached deployment.

## What the historical evidence actually shows

The census was reconstructed from **10,110 permitted raw result cells across 81 archives**, plus 153 exception-only cells. It did not use old verdicts or handoff conclusions. The 848 descriptive solver labels include small pilots and evolving books; they are not 848 complete independent benchmarks. The full census, executable contracts, missing cells, learning-role groups, and matched comparisons are linked in the artifact index.

Seventy-three interrupted cells had explicit continuation policies whose final caches contained every saved prefix entry exactly. Those prefixes were replayed, not purchased twice. Naively summing both archives adds $0.64806857 of duplicate recorded calls. The reconciled analysis removes that duplication while preserving the interrupted files. It makes no zero-bill assumption about missing transport metadata.

Historical dollar figures are recomputed at the common September 19 tariff, including cache writes, rather than copied from archived `price` columns. They are normalized comparison costs, not reconstructed historical invoices. Fresh experiment figures are checked against raw provider responses and the new ledger. Failed calls and failed problems remain in the relevant accounting and denominators.

### Several different baselines had become mixed together

The original experiments used `prove_theorem_agentic`/`prove_theorem_ace`, two core tools, and 32 requests. Later experiments used `prove_theorem_grounded`, 64 requests, `InspectProofState`, focused decision prompts, bounded goal views, and 300 seconds of verifier work. Those later ACE/non-ACE pairs can be valid within their own contract, but they do not reproduce the original agentic experiment simply because a campaign name contains “X3 reproduction.”

This distinction changes the interpretation of apparently promising numbers. The historical session-matched comparison has 50/80 solves on each side and 11.19% lower ACE inference cost; its theorem-cluster 90% interval is −0.32% to 21.44%. Against that campaign's ordinary non-reset baseline, the same ACE-session configuration saves only 1.05%, while improving 47 to 50 solves. Both results matter. Selecting the more expensive reset control as the sole headline comparator would answer a different question.

After exact-prefix reconciliation, the September 18 thesis-selected book has 51/80 solves at $2.25622. Its output-cap-matched non-ACE control has 49/80 at $2.41161: 6.44% savings. The ordinary 32,768-output-token control has 51/80 at $1.71575, making that ACE recipe 31.50% more expensive. Thus the apparently small output cap did not make this solver cheaper. In the later X3 reproduction, the matched 32,768-cap comparison is 46 to 50 solves and 4.78% savings; the 8,192-cap comparison is 51 to 45 solves and 0.94% higher cost.

Earlier code also imposed zero loss in each replicate in some economy gates. That requirement is visible in the experiment source and is stricter than the user's objective. This investigation preserves those original protocols as history, but evaluates the requested average trade-off. Removing a mistaken gate does not turn a measured 1–6% saving into 10%; it does prevent discarding useful candidates merely because one replicate loses a proof.

### The cost problem is dominated by unsuccessful trajectories

For the original validation baseline, 26 failed attempts cost $1.24767213 of $1.77504503 total: **70.3% of all inference spending**. X3 rendering version 2 solves two more attempts, but its 24 failures cost $1.75294794 and its total rises to $2.32188362.

Two X3 failures alone cost about $0.6946. The `amc12a_2019_p21` replicate reaches 778,447 input tokens in one request and emits roughly 1.04 million characters of verifier feedback; the `mathd_numbertheory_37` replicate reaches 522,325 input tokens and roughly 1.68 million feedback characters. The ordinary baseline also has an expensive `amc12a_2020_p21` trajectory, costing $0.20795 and reaching 451,768 input tokens. Repeated expanded proof states accumulate in the conversation and can cross the long-context tariff boundary. This is a trajectory-control problem as well as a playbook-size problem.

Prompt caching is already effective. The original baseline serves 90.28% of input tokens from cache, X3 rv2 89.25%, and X5 rv2 93.28%. Their input bills are $1.01021, $1.52152, and $0.95146 respectively. X5 reads about 20% more raw input than the baseline but pays less for input. Conversely, the successful Sol pilot has a slightly lower cache fraction than its control, 90.97% versus 92.45%, while reducing cumulative input from 4.093 million to 1.255 million tokens and output from 95,510 to 52,328 tokens. The measured pilot gain accompanies shorter trajectories, not improved cache hit rate.

The $0.10 allowance is a stopping threshold checked between requests, not a hard bill ceiling. A single crossing request can overshoot it. Costs are not clipped at ten cents in these results.

## Implementation defects and controlled diagnostics

### Serialization failures were being mistaken for learning behavior

The two monolithic historical adaptations contain eighty rewrite steps and 196 model replies. Only 35 steps produced a usable result. All 161 invalid replies encountered the same YAML error class: unquoted scalar text containing a colon in Rocq syntax, such as an assertion type annotation. An offline transformation that quotes only unquoted single-line `content` scalars makes all 196 saved replies parse and all eighty steps usable. The 35 originally valid parsed values remain identical.

This experiment uses no new model calls and does not change any archived score. It establishes that these ablations cannot cleanly attribute their outcome to conceptual “context collapse”: much of their learning pipeline never accepted the returned text. It does not establish the coverage an adaptively rerun monolithic learner would have obtained.

The new author ladder exposed a second parser problem: the old last-code-block extraction sometimes selected an indented Rocq fence inside a YAML block scalar. The version-3 parser recognizes the outer column-zero serialization fence. On all 266 saved author replies it recovers 266 valid outputs versus 254 for the old parser, preserving all 254 common valid values. The failed extractions caused ten extra requests and two wholly lost role outputs. The full preparation and online study use the repaired parser; the earlier pilot books remain the artifacts actually produced, so their parser failures remain a limitation when comparing author capability.

The census also finds 54 historical curator exceptions caused by a template expecting a missing `theorem` field. They are concentrated in the early offline-three-epoch and warm-online adaptations. They are preparation failures, not evidence that a correctly executed ACE update was ineffective. The current versioned role queries and templates have explicit input contracts; sealed historical strategies and caches are preserved.

### Stronger authors help with some errors, but still need verification

All four full preparations completed eighty reflection/curation outputs plus five terminal audits. Sol's A2, B1, and B2 growth phases produced no unknown-ID merge warnings. Luna's S1 emitted seventy bullet tags, of which 42 referenced nonexistent IDs and were ignored by the deterministic merge. This measures structured-reference reliability under the shared prompt contract, not general model capability. The prompt requests bullet IDs but could state the restriction to existing IDs more explicitly. The matched S1/A2 benchmark measures the resulting books' practical value.

Ten synthetic Rocq probes independently check specific learned claims:

- `nra` proves a simple variable square nonnegative, but fails on the tested affine and product-square expressions. Explicit `Rle_0_sqr` proofs close both compound cases. The old square advice is too general as phrased, while its fallback is useful.
- In the same Rocq file, `About vm_compute` reports no defined object and `vm_compute; reflexivity` successfully proves a closed equality. Object introspection does not test whether a built-in tactic is available. A new Sol reflection and terminal rationale made precisely this mistaken inference.
- The rejected unparenthesized `set x := ...` form has a working parenthesized `set (x := ...)` counterpart. The historical named-`pose` workaround is valid too; it must not be called false merely because another repair exists.
- `field` alone does not prove the tested logarithmic denominator identity. Rewriting the power logarithm and then using `ring` does. Here the learned algebraic repair is substantively wrong for the stated transcendental relation.

These checks distinguish safe but overly broad guidance, incorrect causal explanations, and actually failing repair advice. They also show why a larger author model alone does not certify a rule's correctness. The report does not infer bullet-level causal effects from a solver merely producing a proof consistent with the book.

Six additional synthetic checks expose a more direct failure in the new long book. A2 bullet 58 prescribes `unfold Same_set; intro x; split`. In this library, `Same_set` unfolds to a conjunction of two inclusions. The prescribed sequence fails with “No product even after head-reduction”; splitting before introducing the element compiles. A2 bullet 24 prescribes an untargeted `Rabs_right` rewrite. Under precisely its advertised assumptions, that rewrite fails because it first tries to establish the unknown sign of the left-hand variable. Targeting the right-hand expression with `rewrite (Rabs_right c) by lra` works. A quantified positive-multiplication example also shows that bullet 9's blanket warning against `nra` is too broad, while its explicit monotonicity lemma remains a useful fallback. The sixth check confirms the short P1 book's product-form square assertion.

The provenance of the set-equality error is particularly informative. The assisted `mathd_algebra_224` source run failed after 32 requests. Its reflector offered an unverified repair, the curator described it as directly established by verifier evidence, and the terminal auditor retained it with an incorrect causal explanation. Luna's S1 book contains the same tactic-order error. B1 and B2 instead prescribe the correct split-first sequence: their shared plain source also failed overall, but it had successfully passed this intermediate repair. Thus an unsuccessful trajectory can contain useful verified progress, while an author's explanation of a failed step can still be false. Correctly checking the final proof does not automatically validate the lesson extracted from it.

R1 freezes those three A2 repairs and measures their joint effect on all forty trainX problems with two replicates. Its 80-cell diagnostic separates the claim “these recipes are corrected” from the separate empirical claim “the corrections make this solver cheaper or more successful.” The original paid books and outcomes remain intact. Early drafts of these six probes omitted the domain imports; those missing-symbol failures are preserved and explicitly excluded. The sixteen reported probes use the appropriate imports.

### Completion and accounting must be explicit

During this investigation, a preliminary author assessment was made too early because Delphyne periodically writes intermediate `result.yaml` files. The provisional conclusion favored Luna; the completed pilot favors Sol. The premature artifacts are preserved in an incident directory. The prematurely queued online launches made zero API calls and consumed no benchmark attempts.

The correction is implemented in a campaign-local launcher adapter: a completion receipt is written only after the worker returns, and it hashes both result and cache. Analysis also requires the launch lock to be released and final experiment state to be complete. Source and pilot results have exact HTTP-disabled replay certificates and independent Rocq compilation certificates; the same certification is applied to the final study. Existing shared and sealed launchers were not silently rewritten. A general completion-receipt interface is an out-of-scope suggestion for Delphyne itself.

## What the author and teacher pilots establish

The author study holds eight trainX source trajectories fixed and compares Luna, Terra, Sol, and Astra at medium and high reasoning. The first evidence encoding omitted the informal sketch and tool replies. A second encoding restores the solver's visible inputs and conversation. Both sets of books and their matched twelve-problem pilot evaluations are retained: seventeen arms including the no-book control, 204 attempts total.

With full-input evidence, Sol-medium solves 11/12 at $0.11395045, versus the ordinary control's 9/12 at $0.26757794: **57.41% lower inference cost**. Luna-medium solves 10/12 at $0.15631995. Sol-high is worse than Sol-medium in this pilot, and Astra-high costs more while matching Sol-medium's eleven solves. More model capacity or more reasoning is not monotonically better.

Three pilot problems overlap the eight source trajectories. On the remaining nine, the control solves six at $0.24992996 and the Sol book solves eight at $0.10605873, a 57.56% saving. This reduces the concern that the pilot result is entirely familiar-problem recall, but the pilot remains selected, small, and exploratory. P1 freezes that actual 3,986-character, eleven-bullet book before its full trainX/validationX follow-up.

The per-problem traces explain the pilot difference. On `amc12a_2002_p13`, the control exhausts 32 requests and 23 checks without a proof; Sol's book leads to a checked product-zero factorization in fourteen requests and seven checks. On `mathd_numbertheory_629`, the control fails after 32 requests, while the Sol-book trajectory solves in eighteen using explicit closed LCM replacements after still encountering stack overflows. On `amc12b_2004_p3`, both paths bound exponents and split cases, but Sol's book uses eight requests versus thirteen. Its accepted script contains seventy verifier-supplied `easy` closures: these are genuine checked assistance, not seventy subgoals independently solved by Luna. Easy one-request problems can instead pay extra prompt cost. Here and in the trace tables, “checks” counts distinct cached compute records; cache reuse means this is not necessarily every invocation or every low-level Rocq request.

The training-only completion teacher performs 339 checks on the forty fixed plain trajectories, finds eleven independently rechecked and kernel-compiled scripts on nine theorems, and encounters six work-limited checks. **None of its successful completions comes from a source theorem the plain solver ultimately failed.** It can expose shorter completions and useful intermediate repairs, but this measured teacher did not supply new solved examples for the hardest failures. B1/B2 therefore tests a specific limited source of supervision, not an unlimited oracle.

The retained-rule provenance also identifies a mismatch between training effort and the economic objective. A2's seven failed source problems consume $0.39363 of $0.75239 source spending (52.3%), but introduce twelve of its 57 retained rules and only 19.2% of their content characters. Five one-request successes consume $0.00231 and introduce five rules. B1's nine failures account for 59.9% of source cost and fourteen of 53 retained rules. The short P1 book's eleven rules all originate in seven multi-request successes; its eighth, one-request source contributes no rule. These are source-allocation measurements, not estimates of rule usefulness. They support testing a learning objective that explicitly targets expensive recoverable trajectories, while the compiled set-equality example shows why failed-source lessons still need executable evidence.

## Preparation economics

| Recipe | Source collection | Author and audit calls | Total preparation | Frozen bullets / characters |
|---|---:|---:|---:|---:|
| A2: full Sol, assisted | $0.75239 | $20.40788 | $21.16027 | 57 / 21,079 |
| S1: full Luna, assisted | $0.75239 | $1.00297 | $1.75536 | 57 / 18,938 |
| B1: full Sol, plain | $0.99151 | $26.58647 | $27.57798 | 53 / 18,669 |
| B2: full Sol, teacher evidence | $0.99151 | $43.72839 | $44.71990 | 61 / 21,174 |
| P1: short Sol pilot book | $0.07698 | $2.02092 | $2.09790 | 11 / 3,986 |

These are deployment-recipe costs: each includes the sources it needs. The investigation reuses source trajectories, so adding all table rows would double-count the study bill. If suitable source trajectories already exist, the incremental preparation charge is the author/audit column. The teacher has zero additional LLM API cost for its deterministic proof work, but its longer evidence increases author input cost; measured completion/check/compilation time is reported separately without inventing a machine-dollar tariff.

B2's larger fee has a measurable mechanism. Its authors read 7,511,433 input tokens versus B1's 4,961,585, and two B2 requests cross the 272,000-token tariff boundary, with a maximum of 466,925 tokens. Their output counts are almost unchanged: 88,614 versus 88,940. B2's billed input rises from B1's $24.80767 to $41.91091. The extra teacher evidence therefore increases both volume and, for two requests, the per-token tariff; it is not primarily extra author output reasoning.

### A completed preparation-cost repair

Every full preparation and the selected short-book recipe records **zero cache-read tokens**. Almost all author input instead incurs the cache-write rate. A2 pays $3.72109 in unused write premium, B1 $4.96133, and B2 $8.38197. These are 18.2%, 18.7%, and 19.2% of their respective author bills. Their single-message learning inputs change between calls, and there is no reusable explicit breakpoint inside those messages. Current caching operates at eligible boundaries; explicit mode with no breakpoints avoids writing such one-shot inputs. See the [provider's cache-boundary and explicit-mode specification](https://developers.openai.com/api/docs/guides/prompt-caching#how-caching-works).

A separately registered six-call experiment reuses A2's exact reflection/curation inputs at training steps ten and thirty, plus terminal auditors zero and four. Only the cache mode changes. All six input-token counts remain identical, all six outputs parse under their original role schema, and all six have zero cache reads and writes. Input fees fall from $2.463747 to $1.971012: **20.0% lower**. Total fees fall from $2.674107 to $2.171732, or **18.8% lower**; output-token variation is reported separately. This is an actual paid experiment, not hypothetical repricing. Its generated lessons are diagnostic outputs and do not replace the frozen study books.

The opt-in `learning_cache.one_shot_payload` helper implements this change. It is appropriate for these one-call author requests, whose full preparations needed no parsing retries. It is not applied to the multi-turn solver, which benefits substantially from cached conversation history, or presented as a solver-cost victory. A future author recipe that regularly retries or reuses the same context must account for that reuse before choosing this policy. The original measured preparation fees above remain the actual fees paid; they are not retroactively discounted.

The economics calculation separates ordinary payback from the workload size needed for 10% savings **including preparation**. R1 at the matched $0.09 allowance saves $0.18049658 across eighty attempts. Its $21.16027059 preparation therefore repays after 9,379 similar problems; reaching 10% total savings including preparation takes 166,660 under the observed averages. Manual review time is unpriced. These large thresholds arise because a 10.60% serving improvement leaves only a small margin above a 10% end-to-end target. Those projections assume the measured workload distribution recurs with the same frozen book. They are not guarantees of savings on arbitrary new theorems. Online reporting includes every learning update, including the last one, rather than presenting solver-only savings as the whole operating bill.

## Most promising version and improvement direction

**R1 with a matched $0.09 allowance is the clearest completed 10% cost signal.** It saves 10.60% and gains four solves out of eighty on trainX, retains its terminal failure, and respects the accepted average trade-off. Its limits are explicit: familiar problems, manual rule repair, conditional budget replay, a broad interval and a gain concentrated in one theorem. It is a development candidate, not an autonomous transfer claim.

**B2 is the most promising completed transferred playbook comparison.** On validationX it improves both cost and coverage against its matching ordinary plain control, and substantially improves on B1. However, its 3.25% ordinary-baseline saving and $44.71990 preparation do not justify calling it the achieved 10% result. A0's stronger ordinary pipeline remains an essential reference. P1's full results supersede its attractive selected pilot as the basis for choosing a candidate.

The improvement direction follows completed experiments, not a request for an unspecified investigation:

1. **Turn verified repairs into precise, applicable lessons.** The LCM, induction and missing-dependency probes close the actual original problems; the set-equality and absolute-value probes identify incorrect learned rules. Preserve the source state, prerequisites and compiler receipt, and distinguish a proposed repair from checked evidence. R1 tests three such corrections together; its unmodified A2 comparison is part of the remaining fixed schedule (hints #140 and #144).
2. **Control the failed-trajectory tail.** A2 is cheaper on shared successes but loses that saving on failures; a single LCM theorem costs more than its aggregate regression. Bound all feedback fields, including error strings, and avoid eager expansion of large natural-number terms. The $0.05 budget alone cannot prevent a request whose prefix costs less than five cents but whose context is already enormous (hints #109 and #143).
3. **Repair shared parsing and distinguish generation waste from reasoning.** The parser/controller experiment already saves one request and recovers a budget-limited baseline proof. B1's excess capped replies explain 68.78% of its total cost gap to B2. Whole-proof repetition consumes output tokens without adding independent proof attempts. Apply a general parser correction consistently to both ordinary and ACE solvers in a subsequent contract; the current registered paid comparison remains unchanged.
4. **Keep stronger models in preparation, and measure their actual output.** Sol-medium won the bounded author pilot; stronger or higher-effort models did not improve monotonically. They still emitted incorrect rules. S1 and O1 are the already registered comparisons for inexpensive authors and adaptive preparation, respectively; both keep Luna as the solver. The teacher's limited supervision should be described by the actual compiled examples it supplies (hints #140 and #142).
5. **Use the measured author cache repair where there is no reuse.** Six actual calls reduce input fees by 20.0% and total fees by 18.8%, with all outputs schema-valid. This is preparation saving, separate from the ten-percent solver objective. Do not apply that cache policy to the multi-turn solver or discount historical charges retroactively (hint #141).
6. **Treat selected pilots as evidence for a fixed follow-up, not as the final effect estimate.** P1's original advantage reverses on the very same twelve problems under identical initial requests. Both good and bad repeats stay in the full denominator; the favorable other-28 subset is not promoted into a headline (hint #145).

No extra sweeps, replacement failures, new models for solving, or additional seeds have been added. The 421 attempts still lacking final outcomes belong to the original registered scope. The conservative timeout reconciliation uses the existing API authorization. The later credit interruption is preserved for exact continuation when account access is restored.

## Verification and reproducibility

The [current returned-study inventory](quota_checkpoint_inventory.json) contains **1,619 exact normal replays and four certified terminal-prefix/request replays**, all without HTTP. **989 distinct independently compiled proofs cover all 1,229 returned solved outcomes**. There are 1,099 completed frozen cells with 3,297 exact lower-budget scenarios. The credit-interrupted trajectory has four guarded prefix replays but remains incomplete. The [receipt certificate](quota_checkpoint_receipt_certification.json) independently reprices every returned provider response and retains the separate timeout's invoice interval. Historical certification separately covers all 3,485 distinct returned scripts and 4,953 solved permitted cells. Manual repair and parser-probe proofs are excluded from those benchmark counts.

The seven validation panels are complete, matched eighty-cell denominators. Both online curricula pass the full eighty-update chronology certificate. The timeout is the only request without exact settled usage, and its full liability remains reserved. The reporting implementation supports this reconciled bounded invoice without presenting it as exact: comparisons expose endpoint ranges, cost targets must survive the adverse endpoint, and an affected exact cost p-value is omitted. All other unknown receipts still block. Offline tests cover the recovery, interval and continuation contracts; 27 existing exact comparisons retain identical statistics after the interval extension. All 100 sealed files for the returned main batch remain unchanged.

Code changes and diagnostics stay within `examples/omphalos`. The campaign includes dated tariff reconstruction, completion receipts, terminal-failure accounting, repaired outer-YAML learning parsing, scope checks, independent kernel compilation, budget replay and numerical reporting. The original paid books, prompts, caches and outcomes remain immutable. The tested shared-solver parser recovery is local and diagnostic; the generic framework change is only suggested.

Verification passes 21 scoped tests, Ruff, the repository type-check and the dual-harness invariant target. The installed Pyright version is 1.1.409; it was not changed for this study. Aggregate tests, global repricing and eager legacy partition loaders are excluded because they may open closed data. Both Codex and Claude Code can use the same Python entry points. **Only trainX and validationX were used.** ValidationX remains reused development data; protected challenge data and testX remain closed.

The [evidence index](artifact_index.md) links the complete measurements and local probes. The [package README](../../experiments/ace_independent_audit/README.md) supplies reproduction commands. Large caches and raw provider responses remain local with recorded hashes; no credential is copied into the review bundle. Changes remain staged and uncommitted for the user's review. The original checkpoint is retained in its exact review snapshot, so the corrected interpretation of P1 does not overwrite the history of its selection.
